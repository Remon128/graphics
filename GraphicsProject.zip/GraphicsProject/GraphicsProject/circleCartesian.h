#pragma once
#include "Circle.h"
class circleCartesian :
	public Circle
{
public:
	circleCartesian();
	~circleCartesian();
	void DrawCircle(HDC &hdc, int xc, int yc, int R, COLORREF color);
};

