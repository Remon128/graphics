#pragma once
class Circle
{
public:
	Circle();
	~Circle();
	virtual void DrawCircle(HDC &hdc, int xc, int yc, int R, COLORREF color);
};

