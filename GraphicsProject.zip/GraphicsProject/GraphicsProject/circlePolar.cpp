#include "stdafx.h"
#include "circlePolar.h"
#include "math.h"


circlePolar::circlePolar()
{
}


circlePolar::~circlePolar()
{
}

void circlePolar::DrawCircle(HDC & hdc, int x0, int y0, int R, COLORREF color)
{
	int x = R, y = 0;
	double theta = 0, dtheta = 1.0 / R;
	SetPixel(hdc, x0 + x, y0 + y, color);
	SetPixel(hdc, x0 + y, y0 + x, color);
	SetPixel(hdc, x0 - y, y0 + x, color);
	SetPixel(hdc, x0 - x, y0 + y, color);
	SetPixel(hdc, x0 - x, y0 - y, color);
	SetPixel(hdc, x0 - y, y0 - x, color);
	SetPixel(hdc, x0 + y, y0 - x, color);
	SetPixel(hdc, x0 + x, y0 - y, color);
	while (x>y)
	{
		theta += dtheta;
		x = round(R*cos(theta));
		y = round(R*sin(theta));
		SetPixel(hdc, x0 + x, y0 + y, color);
		SetPixel(hdc, x0 + y, y0 + x, color);
		SetPixel(hdc, x0 - y, y0 + x, color);
		SetPixel(hdc, x0 - x, y0 + y, color);
		SetPixel(hdc, x0 - x, y0 - y, color);
		SetPixel(hdc, x0 - y, y0 - x, color);
		SetPixel(hdc, x0 + y, y0 - x, color);
		SetPixel(hdc, x0 + x, y0 - y, color);
	}

}
