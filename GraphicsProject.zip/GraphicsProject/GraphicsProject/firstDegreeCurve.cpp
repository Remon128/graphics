#include "stdafx.h"
#include "firstDegreeCurve.h"


firstDegreeCurve::firstDegreeCurve()
{
}


firstDegreeCurve::~firstDegreeCurve()
{
}

void firstDegreeCurve::Draw1dcurve(HDC &hdc, int x0, int y0, int x1, int y1, COLORREF color)
{
	double x, y;
	int alphax, alphay, betax, betay;
	betax = x0;
	betay = y0;
	alphax = x1 - x0;
	alphay = y1 - y0;
	double n = max(abs(alphay), abs(alphax));
	for (double i = 0; i <= 1; i += 1 / n) {
		x = alphax*i + betax;
		y = alphay*i + betay;
		SetPixel(hdc, x, y, color);
	}
}
