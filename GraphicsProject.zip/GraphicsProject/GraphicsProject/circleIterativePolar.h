#pragma once
#include "Circle.h"
class circleIterativePolar :
	public Circle
{
public:
	circleIterativePolar();
	~circleIterativePolar();
	void DrawCircle(HDC &hdc, int xc, int yc, int R, COLORREF color);
};

