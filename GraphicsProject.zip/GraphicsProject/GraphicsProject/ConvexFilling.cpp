#include "stdafx.h"
#include "ConvexFilling.h"
#include "math.h"


 

ConvexFilling::ConvexFilling()
{
}


ConvexFilling::~ConvexFilling()
{
}

void ConvexFilling::DDAdrawLine(HDC hdc, int x1, int y1, int x2, int y2)
{
	int dy = y2 - y1;
	int dx = x2 - x1;
	if (abs(dy)<abs(dx)) {
		if (x2<x1) {
			int tmp = x2;
			x2 = x1;
			x1 = tmp;
			tmp = y2;
			y2 = y1;
			y1 = tmp;
		}
		double x = x1;
		double y = y1;
		while (x<x2) {
			y = y1 + double(dy) / double(dx)*(x - x1);
			SetPixel(hdc, x, y, RGB(100, 100, 100));
			x = x + 1;

		}
	}
	else {
		if (y2<y1) {
			int tmp = x2;
			x2 = x1;
			x1 = tmp;
			tmp = y2;
			y2 = y1;
			y1 = tmp;
		}
		double x = x1;
		double y = y1;

		while (y<y2) {
			x = x1 + double(dx) / double(dy)*(y - y1);
			SetPixel(hdc, x, y, RGB(100, 100, 100));
			y = y + 1;
		}
	}

}

void ConvexFilling::Swap(POINT & v1, POINT & v2)
{
	int tempx, tempy;
	tempx = v1.x;
	v1.x = v2.x;
	v2.x = tempx;

	tempy = v1.y;
	v1.y = v2.y;
	v2.y = tempy;
}

void ConvexFilling::initial_edgtbl(edgrec * tbl, int n)
{
	for (int i = 0; i < n; i++)
	{
		tbl[i].xleft = 2048;
		tbl[i].xright = 0;
	}
}

void ConvexFilling::from_edg_to_edgtbl(POINT & p1, POINT & p2, edgrec * tbl)
{
	if (p1.y == p2.y)return;
	if (p1.y>p2.y)
	{
		Swap(p1, p2);
	}

	int y = p1.y;
	double x = p1.x;
	//initializatio for color
	double mi = double(p2.x - p1.x) / (p2.y - p1.y);
	//double ci = delta G/delte y

	while (y < p2.y)
	{
		if (x < tbl[y].xleft)
			tbl[y].xleft = (int)ceil(x);
		if (x > tbl[y].xright)
			tbl[y].xright = (int)floor(x);
		y++;
		x += mi;
		//G += ci;
	}
}

void ConvexFilling::from_polygon_to_edgtbl(POINT p[], int n, edgrec * tbl)
{
	POINT v1;
	v1.x = p[n - 1].x;
	v1.y = p[n - 1].y;
	for (int i = 0; i < n; i++)
	{
		POINT v2;
		v2.x = p[i].x;
		v2.y = p[i].y;
		from_edg_to_edgtbl(v1, v2, tbl);
		v1.x = p[i].x;
		v1.y = p[i].y;
	}
}

void ConvexFilling::ConvexFill(HDC &hdc, POINT p[], int n, COLORREF color)
{
	edgrec *tbl = new edgrec[800];
	initial_edgtbl(tbl, 800);
	from_polygon_to_edgtbl(p, n, tbl);
	for (int i = 0; i < 800; i++)
	{
		if (!(tbl[i].xleft == 800 || tbl[i].xright == 0))
			DDAdrawLine(hdc, tbl[i].xleft, i, tbl[i].xright, i);

	}
	delete tbl;
}
