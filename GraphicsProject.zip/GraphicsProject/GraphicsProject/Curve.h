#pragma once
class Curve
{
public:
	Curve();
	~Curve();

};

