#pragma once
class PointClipping
{
public:
	PointClipping();
	~PointClipping();
	void pointClipping(HDC hdc, int x, int y, int xleft, int ytop, int xright, int ybottom, COLORREF color);
};

