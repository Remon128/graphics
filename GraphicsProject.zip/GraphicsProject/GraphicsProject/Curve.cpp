#include "stdafx.h"
#include "Curve.h"


Curve::Curve()
{
}


Curve::~Curve()
{
}
