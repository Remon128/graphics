#include "stdafx.h"
#include "parametric.h"


parametric::parametric()
{
}


parametric::~parametric()
{
}

void parametric::DrawLine(HDC & hdc, int xs, int ys, int xe, int ye)
{
	int dx = xe - xs;
	int dy = ye - ys;
	double slope = (double)dy / dx;
	if (xs>xe)
	{
		int tmp = xs;
		xs = xe;
		xe = tmp;

		tmp = ys;
		ys = ye;
		ye = tmp;

	}
	for (int x = xs; x <= xe; x++)
	{
		int y = (int)((ys + (x - xs)*slope)+0.5);
		SetPixel(hdc, x, y, RGB(100, 100, 100));
	}

}
