#include "stdafx.h"
#include "circleCartesian.h"
#include "math.h"


circleCartesian::circleCartesian()
{
}


circleCartesian::~circleCartesian()
{
}

void circleCartesian::DrawCircle(HDC & hdc, int x0, int y0, int R, COLORREF color)
{
	int x = 0, y = R;
	int R2 = R*R;
	SetPixel(hdc, x0 + x, y0 + y, color);
	SetPixel(hdc, x0 + y, y0 + x, color);
	SetPixel(hdc, x0 - y, y0 + x, color);
	SetPixel(hdc, x0 - x, y0 + y, color);
	SetPixel(hdc, x0 - x, y0 - y, color);
	SetPixel(hdc, x0 - y, y0 - x, color);
	SetPixel(hdc, x0 + y, y0 - x, color);
	SetPixel(hdc, x0 + x, y0 - y, color);
	while (x<y)
	{
		x++;
		y = (int)((sqrt((double)(R2 - x*x)))+0.5);
		SetPixel(hdc, x0 + x, y0 + y, color);
		SetPixel(hdc, x0 + y, y0 + x, color);
		SetPixel(hdc, x0 - y, y0 + x, color);
		SetPixel(hdc, x0 - x, y0 + y, color);
		SetPixel(hdc, x0 - x, y0 - y, color);
		SetPixel(hdc, x0 - y, y0 - x, color);
		SetPixel(hdc, x0 + y, y0 - x, color);
		SetPixel(hdc, x0 + x, y0 - y, color);
	}

}
