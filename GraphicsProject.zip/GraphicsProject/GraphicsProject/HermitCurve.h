#pragma once
class HermitCurve
{
public:
	HermitCurve();
	~HermitCurve();
	void DrawHermitcurve(HDC &hdc, int x0, int y0, int x1, int y1, int s1x, int s1y, int s2x, int s2y, COLORREF color);
};

