#pragma once
#include "Line.h"

class simpleDDA : public Line
{
public:
	simpleDDA();
	~simpleDDA();
	void DrawLine(HDC &hdc, int x1, int y1, int x2, int y2);
};

