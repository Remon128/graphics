#include "stdafx.h"
#include "CircleBresenham.h"


CircleBresenham::CircleBresenham()
{
}


CircleBresenham::~CircleBresenham()
{
}

void CircleBresenham::DrawCircle(HDC & hdc, int x0, int y0, int R, COLORREF color)
{
	int x = 0, y = R;
	int d = 1 - R;
	SetPixel(hdc, x0 + x, y0 + y, color);
	SetPixel(hdc, x0 + y, y0 + x, color);
	SetPixel(hdc, x0 - y, y0 + x, color);
	SetPixel(hdc, x0 - x, y0 + y, color);
	SetPixel(hdc, x0 - x, y0 - y, color);
	SetPixel(hdc, x0 - y, y0 - x, color);
	SetPixel(hdc, x0 + y, y0 - x, color);
	SetPixel(hdc, x0 + x, y0 - y, color);
	while (x<y)
	{
		if (d<0)
			d += 2 * x + 2;
		else
		{
			d += 2 * (x - y) + 5;
			y--;
		}
		x++;
		SetPixel(hdc, x0 + x, y0 + y, color);
		SetPixel(hdc, x0 + y, y0 + x, color);
		SetPixel(hdc, x0 - y, y0 + x, color);
		SetPixel(hdc, x0 - x, y0 + y, color);
		SetPixel(hdc, x0 - x, y0 - y, color);
		SetPixel(hdc, x0 - y, y0 - x, color);
		SetPixel(hdc, x0 + y, y0 - x, color);
		SetPixel(hdc, x0 + x, y0 - y, color);
	}
}
