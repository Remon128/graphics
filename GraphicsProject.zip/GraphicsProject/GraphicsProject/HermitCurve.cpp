#include "stdafx.h"
#include "HermitCurve.h"


HermitCurve::HermitCurve()
{
}


HermitCurve::~HermitCurve()
{
}

void HermitCurve::DrawHermitcurve(HDC & hdc, int x0, int y0, int x1, int y1, int s1x, int s1y, int s2x, int s2y, COLORREF color)
{
	double x, y;
	int alphax, alphay, betax, betay, gammax, gammay, omegax, omegay;
	omegax = x0;
	omegay = y0;
	gammax = s1x;
	gammay = s1y;
	betax = -3 * x0 - 2 * s1x + 3 * x1 - s2x;
	betay = -3 * y0 - 2 * s1y + 3 * y1 - s2y;
	alphax = 2 * x0 + s1x - 2 * x1 + s2x;
	alphay = 2 * y0 + s1y - 2 * y1 + s2y;
	//double n= max(abs(alphay),abs(alphax));
	for (double i = 0; i <= 1; i += 0.0001) {
		x = alphax*i*i*i + betax*i*i + gammax*i + omegax;
		y = alphay*i*i*i + betay*i*i + gammay*i + omegay;
		SetPixel(hdc, x, y, color);
	}
}
