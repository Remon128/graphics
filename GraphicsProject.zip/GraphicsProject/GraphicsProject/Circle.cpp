#include "stdafx.h"
#include "Circle.h"


Circle::Circle()
{
}


Circle::~Circle()
{
}

void Circle::DrawCircle(HDC & hdc, int xc, int yc, int R, COLORREF color)
{

}
