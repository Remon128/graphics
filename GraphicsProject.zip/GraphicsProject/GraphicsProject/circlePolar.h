#pragma once
#include "Circle.h"
class circlePolar :
	public Circle
{
public:
	circlePolar();
	~circlePolar();
	void DrawCircle(HDC &hdc, int xc, int yc, int R, COLORREF color);
};

