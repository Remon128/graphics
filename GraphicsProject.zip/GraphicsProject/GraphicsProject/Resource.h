//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GraphicsProject.rc
//

#define IDS_APP_TITLE			103

#define IDR_MAINFRAME			128
#define IDD_GRAPHICSPROJECT_DIALOG	102
#define IDD_ABOUTBOX			103
#define IDM_ABOUT				104
#define IDM_EXIT				105

#define IDM_Param               200
#define IDM_SimpleDDA		    201
#define IDM_Midpoint			202

#define IDM_cCart				203
#define IDM_Polar               204
#define IDM_IPolar              205
#define IDM_Bres                206

#define IDM_1stCurve            207
#define IDM_2ndCurve            208
#define IDM_HermitCurve         209
#define IDM_BezierCurve         210

#define IDM_convexFill          211

#define IDM_PointClip           212
#define IDM_LineClip            213

#define IDM_red                 214
#define IDM_green               215
#define IDM_blue                216
#define IDM_white               217

#define IDI_GRAPHICSPROJECT			107
#define IDI_SMALL				108
#define IDC_GRAPHICSPROJECT			109
#define IDC_MYICON				2
#ifndef IDC_STATIC
#define IDC_STATIC				-1
#endif
// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
