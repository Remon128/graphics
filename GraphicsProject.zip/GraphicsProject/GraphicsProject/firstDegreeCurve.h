#pragma once
class firstDegreeCurve
{
public:
	firstDegreeCurve();
	~firstDegreeCurve();
	void Draw1dcurve(HDC &hdc, int x0, int y0, int x1, int y1, COLORREF color);
};

