#include "stdafx.h"
#include "simpleDDA.h"


simpleDDA::simpleDDA()
{
}


simpleDDA::~simpleDDA()
{
}

void simpleDDA::DrawLine(HDC &hdc, int x1, int y1, int x2, int y2)
{

	int dy = y2 - y1;
	int dx = x2 - x1;

	if (abs(dy)<abs(dx))
	{
		if (x2<x1)
		{
			int tmp = x2;
			x2 = x1;
			x1 = tmp;
			tmp = y2;
			y2 = y1;
			y1 = tmp;
		}
		double x = x1;
		double y = y1;
		while (x<x2)
		{
			x = x + 1;
			y = y1 + double(dy) / double(dx)*(x - x1);
			SetPixel(hdc, x, y, RGB(200, 0, 0));
		}
	}
	else
	{
		if (y2<y1)
		{
			int tmp = x2;
			x2 = x1;
			x1 = tmp;
			tmp = y2;
			y2 = y1;
			y1 = tmp;
		}
		double x = x1;
		double y = y1;
		while (y<y2)
		{
			y = y + 1;
			x = x1 + double(dx) / double(dy)*(y - y1);
			SetPixel(hdc, x, y, RGB(200, 200, 200));
		}
	}
}
