// GraphicsProject.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "GraphicsProject.h"
#include "Line.h"
#include "simpleDDA.h"
#include "midPoint.h"
#include "Circle.h"
#include "CircleBresenham.h"
#include "parametric.h"
#include "circleCartesian.h"
#include "circleIterativePolar.h"
#include "circlePolar.h"
#include "firstDegreeCurve.h"
#include "BezierCurve.h"
#include "HermitCurve.h"
#include "ConvexFilling.h"
#include "PointClipping.h"
#include "LineClipping.h"

#define MAX_LOADSTRING 100

bool bSimpleDDA = false;
bool bMidpoint = false;
bool bcBres = false;
bool bParam = false;
bool bcCart = false;
bool bcIPol = false;
bool bcPol = false;
bool bfrstCurve = false;
bool bsecondCurve = false;
bool bHermiteCurve = false;
bool bBezierCurve = false;
bool bConvexFill = false;
bool bPointclip = false;
bool bLineclip = false;
bool bred = false;
bool bgreen = false;
bool bblue = false;
bool bwhite = false;

// Global Variables:
HINSTANCE hInst;                                // current instance
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];            // the main window class name

// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Place code here.

    // Initialize global strings
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_GRAPHICSPROJECT, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Perform application initialization:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_GRAPHICSPROJECT));

    MSG msg;

    // Main message loop:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_GRAPHICSPROJECT));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_GRAPHICSPROJECT);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Store instance handle in our global variable

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

union OutCode
{
	unsigned All : 4;
	struct { unsigned left : 1, top : 1, right : 1, bottom : 1; };
};

OutCode GetOutCode(double x, double y, int xleft, int ytop, int xright, int ybottom)
{
	OutCode out;
	out.All = 0;
	if (x<xleft)out.left = 1; else if (x>xright)out.right = 1;
	if (y<ytop)out.top = 1; else if (y>ybottom)out.bottom = 1;
	return out;
}

void VIntersect(double xs, double ys, double xe, double ye, int x, double *xi, double *yi)
{
	*xi = x;
	*yi = ys + (x - xs)*(ye - ys) / (xe - xs);
}
void HIntersect(double xs, double ys, double xe, double ye, int y, double *xi, double *yi)
{
	*yi = y;
	*xi = xs + (y - ys)*(xe - xs) / (ye - ys);
}

void CohenSuth(HDC hdc, int xs, int ys, int xe, int ye, int xleft, int ytop, int xright, int ybottom)
{
	double x1 = xs, y1 = ys, x2 = xe, y2 = ye;
	OutCode out1 = GetOutCode(x1, y1, xleft, ytop, xright, ybottom);
	OutCode out2 = GetOutCode(x2, y2, xleft, ytop, xright, ybottom);
	while ((out1.All || out2.All) && !(out1.All & out2.All))
	{
		double xi, yi;
		if (out1.All)
		{
			if (out1.left)VIntersect(x1, y1, x2, y2, xleft, &xi, &yi);
			else if (out1.top)HIntersect(x1, y1, x2, y2, ytop, &xi, &yi);
			else if (out1.right)VIntersect(x1, y1, x2, y2, xright, &xi, &yi);
			else HIntersect(x1, y1, x2, y2, ybottom, &xi, &yi);
			x1 = xi;
			y1 = yi;
			out1 = GetOutCode(x1, y1, xleft, ytop, xright, ybottom);
		}
		else
		{
			if (out2.left)VIntersect(x1, y1, x2, y2, xleft, &xi, &yi);
			else if (out2.top)HIntersect(x1, y1, x2, y2, ytop, &xi, &yi);
			else if (out2.right)VIntersect(x1, y1, x2, y2, xright, &xi, &yi);
			else HIntersect(x1, y1, x2, y2, ybottom, &xi, &yi);
			x2 = xi;
			y2 = yi;
			out2 = GetOutCode(x2, y2, xleft, ytop, xright, ybottom);
		}
	}
	if (!out1.All && !out2.All)
	{
		MoveToEx(hdc, round(x1), round(y1), NULL);
		LineTo(hdc, round(x2), round(y2));
	}
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//

void changeBackground(HWND hWnd, COLORREF color) {
	RECT rect;
	HDC hdc = GetDC(hWnd);
	HBRUSH brush = CreateSolidBrush(color);
	GetWindowRect(hWnd, &rect);
	FillRect(hdc, &rect, brush);
	DeleteObject(brush);
	ReleaseDC(hWnd, hdc);
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
		static int count,xs,ys,xe,ye,rx,ry,xs2,ys2,xe2,ye2,xs3,ys3,xe3,ye3,xs4,ys4,xe4,ye4;
		count = 0;
		static POINT p[4];
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // Parse the menu selections:
            switch (wmId)
            {
            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
			case IDM_SimpleDDA:
				bSimpleDDA = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_Midpoint:
				bMidpoint = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_Param:
				bParam = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_Bres:
				bcBres = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_cCart:
				bcCart = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_Polar:
				bcPol = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_IPolar:
				bcIPol = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_1stCurve:
				bfrstCurve = true;
		//		InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_HermitCurve:
				bHermiteCurve = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_BezierCurve:
				bBezierCurve = true;
		//		InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_convexFill:
				bConvexFill = true;
			//	InvalidateRect(hWnd, 0, TRUE);
				break;
			case IDM_PointClip:
				bPointclip = true;
				break;
			case IDM_LineClip:
				bLineclip = true;
				break;
			case IDM_red:
				changeBackground(hWnd, RGB(200, 0, 0));
				break;
			case IDM_green:
				changeBackground(hWnd, RGB(0, 200, 0));
				break;
			case IDM_blue:
				changeBackground(hWnd, RGB(0, 0, 200));
				break;
			case IDM_white:
				changeBackground(hWnd, RGB(255, 255, 255));
				break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
		
	case WM_LBUTTONDOWN:
		if (count == 0) {
			xs = LOWORD(lParam);
			ys = HIWORD(lParam);
			rx = LOWORD(lParam);
			ry = HIWORD(lParam);
			count++;
			p[count].x = xs;
			p[count].y = ys;
		}
		else if (count == 1) {
			xe = LOWORD(lParam);
			ye = HIWORD(lParam);
			rx = LOWORD(lParam);
			ry = HIWORD(lParam);
			count++;
			p[count].x = xe;
			p[count].y = ye;
		}
		else if (count == 2) {
			xs2 = LOWORD(lParam);
			ys2 = HIWORD(lParam);
			count++;
			p[count].x = xs2;
			p[count].y = ys2;
		}
		else if (count == 3) {
			xe2 = LOWORD(lParam);
			ye2 = HIWORD(lParam);
			count++;
			p[count].x = xe2;
			p[count].y = ye2;
		}
		else if (count == 4) {
			xs3 = LOWORD(lParam);
			ys3 = HIWORD(lParam);
			count++;
		}
		else if (count == 5) {
			xe3 = LOWORD(lParam);
			ye3 = HIWORD(lParam);
			count++;
		}
		break;
    case WM_PAINT:
        {
          //  PAINTSTRUCT ps;
         //   HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: Add any drawing code that uses hdc here...
	//	changeBackground(hWnd, RGB(200, 0, 0));
		HDC hdc = GetDC(hWnd);
			if (bSimpleDDA && count==2) {
				
				Line *line = new simpleDDA();
				line->DrawLine(hdc, xs , ys , xe ,ye);
				count = 0;
				bSimpleDDA = false;
			}
			if (bMidpoint && count == 2) {
				
				Line *line = new midPoint();
				line->DrawLine(hdc, xs, ys, xe, ye);
				count = 0;
				bMidpoint = false;
			}
			if (bParam && count == 2) {

				Line *line = new parametric();
				line->DrawLine(hdc, xs, ys, xe, ye);
				count = 0;
				bParam = false;
			}
			if (bcBres && count==1) {
				Circle *circle = new CircleBresenham();
				circle->DrawCircle(hdc,xs,ys,ry,RGB(200,100,300));
				count = 0;
				bcBres = false;
			}
			if (bcCart && count==1) {
				Circle *circle = new circleCartesian();
				circle->DrawCircle(hdc, xs, ys, ry, RGB(200, 100, 300));
				count = 0;
				bcCart = false;
			}
			if (bcPol && count == 1) {
				Circle *circle = new circlePolar();
				circle->DrawCircle(hdc, xs, ys, ry, RGB(200, 100, 300));
				count = 0;
				bcPol = false;
			}
			if (bcIPol && count == 1) {
				Circle *circle = new circleIterativePolar();
				circle->DrawCircle(hdc, xs, ys, ry, RGB(200, 100, 300));
				count = 0;
				bcIPol = false;
			}
			if (bfrstCurve && count == 2) {
				firstDegreeCurve *fdegcurve = new firstDegreeCurve();
				fdegcurve->Draw1dcurve(hdc, xs, ys, xe, ye, RGB(200, 100, 300));
				count = 0;
				bfrstCurve = false;
			}
			if (bHermiteCurve && count == 4) {
				HermitCurve *hcurve = new HermitCurve();
				hcurve->DrawHermitcurve(hdc, xs,ys,xe,ye,(xs2 -xs),(ys2 - ys),(xe2-xe),(ye2-ye), RGB(200, 100, 300));
				count = 0;
				bHermiteCurve = false;
			}
			if (bBezierCurve && count == 4) {
				BezierCurve *bcurve = new BezierCurve();
				bcurve->DrawBeizercurve(hdc, xs, ys, xs2, ys2, xe, ye, xe2, ye2, RGB(200, 100, 300));
				count = 0;
				bBezierCurve = false;
			}
			if (bConvexFill && count == 4) {
				ConvexFilling *convex = new ConvexFilling();
				convex->ConvexFill(hdc, p , 4, RGB(200, 0, 0));
				count = 0;
				bConvexFill = false;
			}
			if (bPointclip && count == 5) {
				PointClipping *pointclip = new PointClipping();
				pointclip->pointClipping(hdc, xs3, ys3, xs, ye, xs2, ye2, RGB(200, 0, 0));
				count = 0;
				bPointclip = false;
			}
			if (bLineclip && count == 6) {
				CohenSuth(hdc, xs3, ys3, xe3, ye3, xs, ye, xs2, ye2);
			}

         //   EndPaint(hWnd, &ps);
			ReleaseDC(hWnd, hdc);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
