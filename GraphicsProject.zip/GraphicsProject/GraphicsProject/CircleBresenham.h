#pragma once
#include "Circle.h"
class CircleBresenham :public Circle
{
public:
	CircleBresenham();
	~CircleBresenham();
	void DrawCircle(HDC &hdc, int xc, int yc, int R, COLORREF color);
};

