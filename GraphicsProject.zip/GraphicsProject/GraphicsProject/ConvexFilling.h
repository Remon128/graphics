#pragma once
class ConvexFilling
{
public:
	ConvexFilling();
	~ConvexFilling();

	struct edgrec {
		int xleft;
		int xright;
		edgrec()
		{
			xleft = 800;
			xright = 0;
		}
		edgrec(int x, int y) {
			xleft = x;
			xright = y;
		}
	};
	
	void ConvexFill(HDC &hdc, POINT p[], int n, COLORREF color);
	void DDAdrawLine(HDC hdc, int x1, int y1, int x2, int y2);
	void from_polygon_to_edgtbl(POINT p[], int n, edgrec *tbl);
	void from_edg_to_edgtbl(POINT &p1, POINT &p2, edgrec *tbl);
	void initial_edgtbl(edgrec *tbl, int n);
	void Swap(POINT &v1, POINT &v2);
	
};

