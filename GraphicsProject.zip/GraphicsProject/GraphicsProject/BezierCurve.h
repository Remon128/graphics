#pragma once
class BezierCurve
{
public:
	BezierCurve();
	~BezierCurve();

	void DrawBeizercurve(HDC &hdc, int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, COLORREF color);
};

