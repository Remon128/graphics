#include "stdafx.h"
#include "midPoint.h"


midPoint::midPoint()
{
}


midPoint::~midPoint()
{
}

void midPoint::DrawLine(HDC &hdc, int x1, int y1, int x2, int y2)
{
	double dx = x2 - x1;
	double dy = y2 - y1;
	if (dy<0)
	{
		dy *= -1;

		double change1 = dx - dy;
		double change2 = -dy;
		double change3 = dx;
		double change4 = dx - dy;
		int x = x1;
		int y = y1;
		SetPixel(hdc, x, y, RGB(100, 100, 100));


		if (dy<dx)
		{
			int d0 = 0.5*dx - dy;
			int d = d0;
			while (x<x2)
			{

				if (d<0)
				{
					x++;
					y++;
					d += change1;
				}
				else
				{
					x++;
					d += change2;
				}
				SetPixel(hdc, x, y - 2 * (y - y1), RGB(100, 100, 100));
			}

		}
		else
		{
			int d0 = dx - dy*0.5;
			int d = d0;

			while (x<x2)
			{

				if (d<0)
				{
					y++;
					d += change3;

				}
				else
				{
					x++;
					y++;
					d += change4;
				}
				SetPixel(hdc, x, y - 2 * (y - y1), RGB(100, 100, 100));

			}

		}

	}
	else
	{
		double change1 = dx - dy;
		double change2 = -dy;
		double change3 = dx;
		double change4 = dx - dy;
		int x = x1;
		int y = y1;
		SetPixel(hdc, x, y, RGB(100, 100, 100));


		if (dy<dx)
		{
			int d0 = 0.5*dx - dy;
			int d = d0;
			while (x<x2)
			{

				if (d<0)
				{
					x++;
					y++;
					d += change1;
				}
				else
				{
					x++;
					d += change2;
				}
				SetPixel(hdc, x, y, RGB(100, 100, 100));
			}

		}
		else
		{
			int d0 = dx - dy*0.5;
			int d = d0;

			while (x<x2)
			{

				if (d<0)
				{
					y++;
					d += change3;

				}
				else
				{
					x++;
					y++;
					d += change4;
				}
				SetPixel(hdc, x, y, RGB(100, 100, 100));

			}

		}
	}
}
