#pragma once
class Line
{
public:
	Line();
	~Line();
	virtual void DrawLine(HDC &hdc, int x1, int y1, int x2, int y2);
};

