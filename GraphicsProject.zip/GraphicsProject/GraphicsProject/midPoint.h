#pragma once
#include "Line.h"
class midPoint : public Line
{
public:
	midPoint();
	~midPoint();
	void DrawLine(HDC &hdc, int x1, int y1, int x2, int y2);
};

