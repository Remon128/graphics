#include "stdafx.h"
#include "Line.h"


Line::Line()
{

}


Line::~Line()
{

}

void Line::DrawLine(HDC &hdc, int x1, int y1, int x2, int y2)
{

}