#include "stdafx.h"
#include "circleIterativePolar.h"
#include "math.h"


circleIterativePolar::circleIterativePolar()
{
}


circleIterativePolar::~circleIterativePolar()
{
}

void circleIterativePolar::DrawCircle(HDC & hdc, int x0, int y0, int R, COLORREF color)
{
	double x = R, y = 0;
	double dtheta = 1.0 / R;
	double cdtheta = cos(dtheta), sdtheta = sin(dtheta);
	SetPixel(hdc, x0 + x, y0 + y, color);
	SetPixel(hdc, x0 + y, y0 + x, color);
	SetPixel(hdc, x0 - y, y0 + x, color);
	SetPixel(hdc, x0 - x, y0 + y, color);
	SetPixel(hdc, x0 - x, y0 - y, color);
	SetPixel(hdc, x0 - y, y0 - x, color);
	SetPixel(hdc, x0 + y, y0 - x, color);
	SetPixel(hdc, x0 + x, y0 - y, color);
	while (x>y)
	{
		double x1 = x*cdtheta - y*sdtheta;
		y = x*sdtheta + y*cdtheta;
		x = x1;
		SetPixel(hdc, x0 + x, y0 + y, color);
		SetPixel(hdc, x0 + y, y0 + x, color);
		SetPixel(hdc, x0 - y, y0 + x, color);
		SetPixel(hdc, x0 - x, y0 + y, color);
		SetPixel(hdc, x0 - x, y0 - y, color);
		SetPixel(hdc, x0 - y, y0 - x, color);
		SetPixel(hdc, x0 + y, y0 - x, color);
		SetPixel(hdc, x0 + x, y0 - y, color);
	}

}
