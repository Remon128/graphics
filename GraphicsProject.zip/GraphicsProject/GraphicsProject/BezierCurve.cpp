#include "stdafx.h"
#include "BezierCurve.h"


BezierCurve::BezierCurve()
{
}


BezierCurve::~BezierCurve()
{
}

void BezierCurve::DrawBeizercurve(HDC & hdc, int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, COLORREF color)
{
	double x, y;
	int alphax, alphay, betax, betay, gammax, gammay, omegax, omegay;
	omegax = x0;
	omegay = y0;
	gammax = 3 * (x1 - x0);
	gammay = 3 * (y1 - y0);
	betax = 3 * (x0 + x2 - 2 * x1);
	betay = 3 * (y0 + y2 - 2 * y1);
	alphax = x3 - x0 + 3 * (x1 - x2);
	alphay = y3 - y0 + 3 * (y1 - y2);
	//double n= max(abs(alphay),abs(alphax));
	for (double i = 0; i <= 1; i += 0.0001) {
		x = alphax*i*i*i + betax*i*i + gammax*i + omegax;
		y = alphay*i*i*i + betay*i*i + gammay*i + omegay;
		SetPixel(hdc, x, y, color);
	}
}
